//
//  News.swift
//  VKApp1
//
//  Created by Mac on 31.05.2021.
//

import UIKit

struct News {
    let newsAvatar: UIImage?
    let newsText: String
}

