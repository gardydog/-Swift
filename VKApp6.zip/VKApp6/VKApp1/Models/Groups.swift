//
//  Groups.swift
//  VKApp1
//
//  Created by Mac on 22.05.2021.
//

import UIKit

struct Group: Equatable {
    let avatar: UIImage?
    let name: String
}

