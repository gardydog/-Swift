//
//  FriendsTableViewCell.swift
//  VKApp1
//
//  Created by Mac on 22.05.2021.
//

import UIKit

class FriendsTableViewCell: UITableViewCell {

    var savedObject: Any?

    @IBOutlet weak var fritendAvatarImage: UIImageView!
    @IBOutlet weak var friendNameLabel: UILabel!
    
    
    func clearCell() {
        fritendAvatarImage.image = nil
        friendNameLabel.text = nil
        savedObject = nil
    }
    
    override func prepareForReuse() {
        clearCell()
    }
    
    func configure(user: User) {
        fritendAvatarImage.image = user.avatar
        friendNameLabel.text = user.fullName
        savedObject = user

    }
    
    
}
