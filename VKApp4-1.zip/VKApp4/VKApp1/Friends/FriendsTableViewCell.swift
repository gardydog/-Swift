//
//  FriendsTableViewCell.swift
//  VKApp1
//
//  Created by Mac on 22.05.2021.
//

import UIKit

class FriendsTableViewCell: UITableViewCell {

    @IBOutlet weak var fritendAvatarImage: UIImageView!
    @IBOutlet weak var friendNameLabel: UILabel!
    
    
    func clearCell() {
        fritendAvatarImage.image = nil
        friendNameLabel.text = nil
    }
    
    override func prepareForReuse() {
        clearCell()
    }
    
    func configure(image: UIImage?, name: String?) {
        if let image = image {
            fritendAvatarImage.image = image
        }
        
        if let name = name {
            friendNameLabel.text = name
        } else {
            friendNameLabel.text = "no name"
        }
    }
    
    
}
