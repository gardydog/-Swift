//
//  FriendsTableViewController.swift
//  VKApp1
//
//  Created by Mac on 22.05.2021.
//

import UIKit

class FriendsTableViewController: UITableViewController {

    
    var friends = [ User(avatar: UIImage(named: "man1"), name: "Ricardo", surname: "Milos", myPhotos: [UIImage(named: "ricardo1"), UIImage(named: "ricardo2"), UIImage(named: "ricardo3")]),
                    User(avatar: UIImage(named: "man2"), name: "Jason", surname: "Stathem", myPhotos: [UIImage(named: "jason1"), UIImage(named: "jason2"), UIImage(named: "jason3")]),
                    User(avatar: UIImage(named: "man3"), name: "Mike", surname: "White", myPhotos: [UIImage(named: "peppa1"), UIImage(named: "peppa2"), UIImage(named: "peppa3")])
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    // MARK: - Table view data source

//    override func numberOfSections(in tableView: UITableView) -> Int {
//
//        return 0
//    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return friends.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "FriendsTableViewCell", for: indexPath) as? FriendsTableViewCell
        else { return UITableViewCell() }

        let friend = friends[indexPath.row]
        cell.configure(image: friend.avatar, name: friend.fullName)
        
        return cell
    }

    //MARK: - Метод добавляет аватар пользователя и его фотки в коллекцию картинок -
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       guard
        segue.identifier == "fromFriendViewToPhotos",
        let photoCollection = segue.destination as? FriendsCollectionViewController,
        let indexPath = tableView.indexPathForSelectedRow?.row
        else { return }
        photoCollection.photos.append(friends[indexPath].avatar)
        photoCollection.photos.append(contentsOf: friends[indexPath].myPhotos)
        photoCollection.title = friends[indexPath].fullName
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
    

}
