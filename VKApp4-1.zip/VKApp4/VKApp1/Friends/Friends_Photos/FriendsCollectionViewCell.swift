//
//  FriendsCollectionViewCell.swift
//  VKApp1
//
//  Created by Mac on 22.05.2021.
//

import UIKit

class FriendsCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var friendsPhotoImage: UIImageView!
    
    
    func clearCell() {
        friendsPhotoImage.image = nil
    }
    
    override func prepareForReuse() {
       clearCell()
    }
    
    func configure(photoImage: UIImage?) {
        friendsPhotoImage.image = photoImage
    }
    
}
