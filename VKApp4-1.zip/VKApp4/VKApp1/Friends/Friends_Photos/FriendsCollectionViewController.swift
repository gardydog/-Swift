//
//  FriendsCollectionViewController.swift
//  VKApp1
//
//  Created by Mac on 22.05.2021.
//

import UIKit

class FriendsCollectionViewController: UICollectionViewController {

    var photos = [UIImage?]()
    
    let FriendsCollectionViewCell = "FriendsCollectionViewCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
    
    // MARK: UICollectionViewDataSource

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return photos.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: FriendsCollectionViewCell, for: indexPath) as? FriendsCollectionViewCell
        else { return UICollectionViewCell() }
    
        let image = photos[indexPath.item]
        cell.configure(photoImage: image)
    
        return cell
    }

    // MARK: UICollectionViewDelegate

}
