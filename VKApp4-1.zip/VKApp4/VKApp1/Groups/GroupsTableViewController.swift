//
//  GroupsTableViewController.swift
//  VKApp1
//
//  Created by Mac on 22.05.2021.
//

import UIKit

class GroupsTableViewController: UITableViewController {

    let groupsID = "GroupsTableViewCell"
    var groups = [Group(avatar: UIImage(named: "logo1"), name: "MDK"),
                  Group(avatar: UIImage(named: "logo2"), name: "News")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    // MARK: - Table view data source

//    override func numberOfSections(in tableView: UITableView) -> Int {
//
//        return 0
//    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        return groups.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: groupsID, for: indexPath) as? GroupsTableViewCell
        else { return UITableViewCell() }
            
        let group = groups[indexPath.row]
        cell.configure(image: group.avatar, name: group.name)

        return cell
    }
    
//MARK: - Функция1, добавляющая группы в текущий контроллер -
    @IBAction func addGroup(segue: UIStoryboardSegue) {
        guard
            segue.identifier == "addGroup",
            let allGroups = segue.source as? ExtraGroupsTableViewController,
            let indexPath = allGroups.tableView.indexPathForSelectedRow

        else { return }

        let group = allGroups.extraGroups[indexPath.row]
        if !groups.contains(group) {
            groups.append(group)
            tableView.reloadData()
        }
    }
    
//MARK: - Функция, удаляющая группы из контроллера -
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            groups.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    
    }
    
    //Логика функции1 выше:
//    1) Проверить что сега именно та которая нужна +
//    2) взять контроллер на который будет добавленна группа +
//    3) взять индекс нажатой ячейки -
//    4) взять группу которую нужно добавить -
//    5) проверить есть ли такая группа там куда хочу добавить -
//    6) если нет такой группы то добавить ее -
//    7) обновить таблицу в контроллере куда добавляю группу -
    
}
